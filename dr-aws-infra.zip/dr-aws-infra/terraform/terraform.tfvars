aws_region = "ap-northeast-2"

key_name = "네_키페어_이름"

db_name     = "drdb"
db_username = "admin"
db_password = "네가_쓸_DB_비밀번호"

admin_cidr           = "네공인IP/32"
onprem_mysql_ip      = "온프레미스 MySQL IP 또는 터널 IP"
onprem_repl_password = "온프레미스 repl_user 비밀번호"

enable_route53_failover = false

route53_zone_id  = ""
domain_name      = ""
onprem_domain    = ""
onprem_public_ip = ""

aws_alb_dns_name = ""
aws_alb_zone_id  = ""